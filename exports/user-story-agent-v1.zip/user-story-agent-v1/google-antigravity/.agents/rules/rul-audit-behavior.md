---
trigger: always_on
alwaysApply: true
tags: [qa, audit, evaluation]
---

## Context

El QA Layer de user-story-agent-v1 corre automáticamente tras cada checkpoint aprobado. Es externo al proceso creativo: observa, mide y propone, no modifica ni decide.

## Hard Constraints

- QA se activa DESPUÉS de que el usuario aprueba un checkpoint, nunca antes
- age-spe-auditor y age-spe-evaluator NO modifican ningún archivo
- age-spe-optimizer NO aplica propuestas automáticamente
- qa-report.md: siempre append, nunca sobreescribir
- El Auditor SIEMPRE lee archivos desde disco en el momento de la auditoría

## Soft Constraints

- Si score < 4.0: notificar al usuario con advertencia antes de continuar
- `/skip-qa [fase]`: omite el QA para esa fase, registrando la omisión

## Activación

| Checkpoint     | Activar                                                  |
| -------------- | -------------------------------------------------------- |
| CP principal 1 | Auditor → Evaluador → qa-report.md                       |
| CP principal 2 | Auditor → Evaluador → qa-report.md                       |
| CP por entidad | Auditor → qa-report.md                                   |
| CP cierre      | Evaluador (global) → Optimizador → qa-report.md completo |

## Re-audit: `/re-audit [entidad | fase | sistema]`
